var contenedores, inputs;

window.onload = function () {

    contenedores = document.getElementsByClassName("inputCon");

    for (let index = 0; index < contenedores.length; index++) {
        const element = contenedores[index];
        element.value = "";
    }

    inputs = document.getElementsByClassName("textIn");

    for (let index = 0; index < inputs.length; index++) {
        const element = inputs[index];
        element.addEventListener("focusout", function () {

            if (this.value != "") {
                this.className = "textIn has-content";
            } else {
                this.className = "textIn"
            }
        }, false);
    }
};