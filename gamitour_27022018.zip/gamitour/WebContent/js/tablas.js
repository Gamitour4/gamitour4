var selectores, selectoresNav, anterior;

window.onload = function () {
    selectoresLanding = document.getElementsByClassName("selAdmin");
    for (let index = 0; index < selectoresLanding.length; index++) {
        const element = selectoresLanding[index];
        element.addEventListener("click", function () { first(this.getAttribute("value")); }, false);
    }

    selectoresNav = document.getElementsByClassName("selAdminNav");
    for (let index = 0; index < selectoresNav.length; index++) {
        const element = selectoresNav[index];
        element.addEventListener("click", function () {
            select(this.getAttribute("value"));
        }, false);
    }
}

function first(selector) {
    document.querySelector(".navAdmin").style.display = "flex";
    document.querySelector(".landing").style.display = "none";
    document.getElementById(selector).style.display = "block";
    anterior = selector;
}

function select(selector) {
    document.getElementById(anterior).style.display = "none";
    document.getElementById(selector).style.display = "block";
    anterior = selector;
}