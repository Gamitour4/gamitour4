package com.gamitour.dao;

import com.gamitour.genericDao.GenericDAO;
import com.gamitour.modelo.Premio;

public interface PremioDAO extends GenericDAO<Premio, String>{

}
