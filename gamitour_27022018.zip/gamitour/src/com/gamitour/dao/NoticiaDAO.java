package com.gamitour.dao;

import com.gamitour.genericDao.GenericDAO;
import com.gamitour.modelo.Noticia;

public interface NoticiaDAO extends GenericDAO<Noticia,	String>{

}
