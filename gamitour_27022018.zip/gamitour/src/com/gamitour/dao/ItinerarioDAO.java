package com.gamitour.dao;

import com.gamitour.genericDao.GenericDAO;
import com.gamitour.modelo.Itinerario;

public interface ItinerarioDAO extends GenericDAO<Itinerario, String>{
	
}
