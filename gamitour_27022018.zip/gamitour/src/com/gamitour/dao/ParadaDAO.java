package com.gamitour.dao;

import com.gamitour.genericDao.GenericDAO;
import com.gamitour.modelo.Parada;

public interface ParadaDAO extends GenericDAO<Parada, String>{
	
}
