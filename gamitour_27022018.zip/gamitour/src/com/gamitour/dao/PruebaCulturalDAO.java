package com.gamitour.dao;

import com.gamitour.genericDao.GenericDAO;
import com.gamitour.modelo.PruebaCultural;

public interface PruebaCulturalDAO extends GenericDAO<PruebaCultural, String>{

}
